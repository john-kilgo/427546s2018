John Kilgo
Final Project #1
Readme

Sources Used
-> 3-Dimensional Canvas Library - https://threejs.org/docs/index.html
-> Fonts used - http://www.omnibus-type.com/fonts/archivo-narrow/
-> HTML5 Skeleton - https://www.w3schools.com/html/html5_intro.asp
-> Canvas Info  - https://www.w3schools.com/graphics/canvas_reference.asp
-> Mouse Events - https://www.w3schools.com/tags/ref_eventattributes.asp
-> Add event Listener - https://www.w3schools.com/jsref/met_element_addeventlistener.asp
-> HTML Input Tag - https://www.w3schools.com/tags/tag_input.asp

How To Operate

See Manual.

General Information

My submission includes code written by myself, using references for general knowledge, and notices of where I have borrowed or copied from other sources.


This is entirely my own work, except as disclosed in 
the documentation and as commented within my work.

I gave help to the following persons:
None

Signed John W Kilgo VI, 3/28/2018
