John Kilgo
Program #2
Readme

Sources Used
-> HTML5 Skeleton - https://www.w3schools.com/html/html5_intro.asp
-> Canvas Info  - https://www.w3schools.com/graphics/canvas_reference.asp
-> Mouse Events - https://www.w3schools.com/tags/ref_eventattributes.asp
-> Add event Listener - https://www.w3schools.com/jsref/met_element_addeventlistener.asp
-> HTML Input Tag - https://www.w3schools.com/tags/tag_input.asp
-> Canvas Arc - https://www.w3schools.com/tags/canvas_arc.asp
-> https://codepen.io/gibatronic/pen/ogeOeY for trying to make multisided polygon of varying side counts

How To Operate

Enter a score and a radius and press "Apply Settings" to change from the default wheel.

General Information

My submission includes code written by myself, using references for general knowledge, and notices of where I have borrowed or copied from other sources.

The multisided polygon does not work.

The fractal implementation was not started, see note below.

To Impress I Did:
- Allow apply radius to wheel
- Styled my button
- Gave ability to scroll scores using the input parameters on input type
- Improved wheel design by filling in the rim color

Due to time constraints due to heavy workload (approx. 60 hours per week),
I implemented what I could reasonably do of good quality.
Approx. time spent on this assignment: 8 hours.

This is entirely my own work, except as disclosed in 
the documentation and as commented within my work.

I gave help to the following persons:
None

Signed John W Kilgo VI, 3/20/2018
